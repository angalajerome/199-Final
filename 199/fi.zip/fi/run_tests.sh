python "scripts/create_test_script.py"
sudo bash "./scripts/run.sh"
