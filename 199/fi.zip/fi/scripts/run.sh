#!/bin/bash
for i in `seq 1 30`;
do
	sudo mn -c
	python "scripts/update_running_json.py" -dir /home/wmtan/Desktop/199/Final/results/no_hie/base;
	python "scripts/update_no_hie_mn_sc.py" -run $i -mn_dir /home/wmtan/Desktop/199/Final/scripts/mininet_test_scripts/no_hie_base;
	sudo mn --custom "scripts/topology.py" --topo mytopo --switch lxbr,stp=1 --link tc --mac --post scripts/mininet_script --test=none;
	sleep 5;
done



for i in `seq 1 30`;
do
	sudo mn -c
	python "scripts/update_running_json.py" -dir /home/wmtan/Desktop/199/Final/results/no_hie/half_stop_mid;
	python "scripts/update_no_hie_mn_sc.py" -run $i -mn_dir /home/wmtan/Desktop/199/Final/scripts/mininet_test_scripts/no_hie_half_stop_mid;
	sudo mn --custom "scripts/topology.py" --topo mytopo --switch lxbr,stp=1 --link tc --mac --post scripts/mininet_script --test=none;
	sleep 5;
done



for i in `seq 1 30`;
do
	sudo mn -c
	python "scripts/update_running_json.py" -dir /home/wmtan/Desktop/199/Final/results/no_hie/stop_up;
	python "scripts/update_no_hie_mn_sc.py" -run $i -mn_dir /home/wmtan/Desktop/199/Final/scripts/mininet_test_scripts/no_hie_stop_up;
	sudo mn --custom "scripts/topology.py" --topo mytopo --switch lxbr,stp=1 --link tc --mac --post scripts/mininet_script --test=none;
	sleep 5;
done



for i in `seq 1 30`;
do
	sudo mn -c
	python "scripts/update_running_json.py" -dir /home/wmtan/Desktop/199/Final/results/hie_sdn/base;
	python "scripts/update_hie_sdn_mn_sc.py" -run $i -mn_dir /home/wmtan/Desktop/199/Final/scripts/mininet_test_scripts/hie_sdn_base;
	sudo mn --switch ovsk --controller remote --custom "scripts/topology.py" --topo mytopo --link tc --mac --post scripts/mininet_script --test=none;
	sleep 5;
done



for i in `seq 1 30`;
do
	sudo mn -c
	python "scripts/update_running_json.py" -dir /home/wmtan/Desktop/199/Final/results/hie_sdn/half_iperf_mid;
	python "scripts/update_hie_sdn_mn_sc.py" -run $i -mn_dir /home/wmtan/Desktop/199/Final/scripts/mininet_test_scripts/hie_sdn_half_iperf_mid;
	sudo mn --switch ovsk --controller remote --custom "scripts/topology.py" --topo mytopo --link tc --mac --post scripts/mininet_script --test=none;
	sleep 5;
done



for i in `seq 1 30`;
do
	sudo mn -c
	python "scripts/update_running_json.py" -dir /home/wmtan/Desktop/199/Final/results/hie_sdn/iperf_up_stop;
	python "scripts/update_hie_sdn_mn_sc.py" -run $i -mn_dir /home/wmtan/Desktop/199/Final/scripts/mininet_test_scripts/hie_sdn_iperf_up_stop;
	sudo mn --switch ovsk --controller remote --custom "scripts/topology.py" --topo mytopo --link tc --mac --post scripts/mininet_script --test=none;
	sleep 5;
done



for i in `seq 1 30`;
do
	sudo mn -c
	python "scripts/update_running_json.py" -dir /home/wmtan/Desktop/199/Final/results/hie_no_sdn/base;
	python "scripts/update_hie_no_sdn_mn_sc.py" -run $i -mn_dir /home/wmtan/Desktop/199/Final/scripts/mininet_test_scripts/hie_no_sdn_base;
	sudo mn --custom "scripts/topology.py" --topo mytopo --switch lxbr,stp=1 --link tc --mac --post scripts/mininet_script --test=none;
	sleep 5;
done



for i in `seq 1 30`;
do
	sudo mn -c
	python "scripts/update_running_json.py" -dir /home/wmtan/Desktop/199/Final/results/hie_no_sdn/half_stop_mid;
	python "scripts/update_hie_no_sdn_mn_sc.py" -run $i -mn_dir /home/wmtan/Desktop/199/Final/scripts/mininet_test_scripts/hie_no_sdn_half_stop_mid;
	sudo mn --custom "scripts/topology.py" --topo mytopo --switch lxbr,stp=1 --link tc --mac --post scripts/mininet_script --test=none;
	sleep 5;
done



for i in `seq 1 30`;
do
	sudo mn -c
	python "scripts/update_running_json.py" -dir /home/wmtan/Desktop/199/Final/results/hie_no_sdn/stop_up;
	python "scripts/update_hie_no_sdn_mn_sc.py" -run $i -mn_dir /home/wmtan/Desktop/199/Final/scripts/mininet_test_scripts/hie_no_sdn_stop_up;
	sudo mn --custom "scripts/topology.py" --topo mytopo --switch lxbr,stp=1 --link tc --mac --post scripts/mininet_script --test=none;
	sleep 5;
done



for i in `seq 1 30`;
do
	sudo mn -c
	python "scripts/update_running_json.py" -dir /home/wmtan/Desktop/199/Final/results/hie_no_sdn/half_iperf_mid;
	python "scripts/update_hie_no_sdn_mn_sc.py" -run $i -mn_dir /home/wmtan/Desktop/199/Final/scripts/mininet_test_scripts/hie_no_sdn_half_iperf_mid;
	sudo mn --custom "scripts/topology.py" --topo mytopo --switch lxbr,stp=1 --link tc --mac --post scripts/mininet_script --test=none;
	sleep 5;
done



for i in `seq 1 30`;
do
	sudo mn -c
	python "scripts/update_running_json.py" -dir /home/wmtan/Desktop/199/Final/results/hie_no_sdn/iperf_up_stop;
	python "scripts/update_hie_no_sdn_mn_sc.py" -run $i -mn_dir /home/wmtan/Desktop/199/Final/scripts/mininet_test_scripts/hie_no_sdn_iperf_up_stop;
	sudo mn --custom "scripts/topology.py" --topo mytopo --switch lxbr,stp=1 --link tc --mac --post scripts/mininet_script --test=none;
	sleep 5;
done



echo "done"